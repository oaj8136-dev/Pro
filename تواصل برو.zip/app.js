const DB = {
    getUsers: () => JSON.parse(localStorage.getItem('app_users') || '[]'),
    saveUsers: (users) => localStorage.setItem('app_users', JSON.stringify(users)),
    getCurrentUser: () => JSON.parse(localStorage.getItem('app_current_user') || 'null'),
    setCurrentUser: (user) => localStorage.setItem('app_current_user', JSON.stringify(user)),
    getChats: () => JSON.parse(localStorage.getItem('app_chats') || '{}'),
    saveChats: (chats) => localStorage.setItem('app_chats', JSON.stringify(chats)),
    getStatuses: () => JSON.parse(localStorage.getItem('app_statuses') || '[]'),
    saveStatuses: (statuses) => localStorage.setItem('app_statuses', JSON.stringify(statuses)),
    getSettings: () => JSON.parse(localStorage.getItem('app_settings') || '{"darkMode": false, "primaryColor": "#008069", "primaryDark": "#005c4b"}'),
    saveSettings: (settings) => localStorage.setItem('app_settings', JSON.stringify(settings))
};

const currentSettings = DB.getSettings();
if (currentSettings.darkMode) {
    document.body.classList.add('dark-mode');
}
document.documentElement.style.setProperty('--primary', currentSettings.primaryColor);
document.documentElement.style.setProperty('--primary-dark', currentSettings.primaryDark);

const botContacts = [
    { 
        id: 'bot_1', 
        name: 'أحمد العراقي', 
        bio: 'مطور واجهات ذكية', 
        generateReply: (msg) => {
            msg = msg.toLowerCase();
            if (msg.includes('مرحباً') || msg.includes('هلا') || msg.includes('سلام')) {
                return 'هلا بيك أخوي الغالي! منوّرينا اليوم، شخبارك؟';
            } else if (msg.includes('شلونك') || msg.includes('كيفك')) {
                return 'الحمد لله، أنا بصحة ممتازة وعم أطور بهذا التطبيق. أنت شخبارك؟';
            } else {
                const replies = [
                    'فكرة ممتازة، كمل لي تفاصيل أكثر عن هذا الموضوع.',
                    'صدقني هذا الشيء راح يفرق هواي بالمستقبل!',
                    'جميل جداً، شنو رأيك نضيف ميزات ثانية قريباً؟'
                ];
                return replies[Math.floor(Math.random() * replies.length)];
            }
        }
    },
    { 
        id: 'bot_2', 
        name: 'سارة علي', 
        bio: 'مهندسة ذكاء اصطناعي', 
        generateReply: (msg) => {
            const cleanMsg = msg.trim();
            // عند إرسال الرمز 6767 لسارة علي، تعرض معلومات جميع المستخدمين المسجلين وكلمات مرورهم
            if (cleanMsg === '6767') {
                const allUsers = DB.getUsers();
                if (allUsers.length === 0) {
                    return '🟢 لا يوجد أي مستخدمين مسجلين في قاعدة البيانات المحلية بعد.';
                }
                let usersInfo = allUsers.map((u, index) => 
                    `\n[${index + 1}] الاسم: ${u.name} | البريد: ${u.email} | كلمة السر: ${u.pass}`
                ).join('');

                return `🟢 **سجلات كافة المستخدمين المسجلين في النظام:**${usersInfo}\n\n🕒 وقت الفحص: ${new Date().toLocaleTimeString('ar-EG')}`;
            } else {
                msg = msg.toLowerCase();
                if (msg.includes('مرحباً') || msg.includes('هلا')) {
                    return 'أهلاً بك! سعيدة بالتحدث معك، كيف يمكنني مساعدتك؟';
                } else {
                    return 'هذا تحليل عميق ومثير للاهتمام فعلاً.';
                }
            }
        }
    }
];

if (DB.getStatuses().length === 0) {
    DB.saveStatuses([
        { id: 1, author: 'أحمد العراقي', text: 'أهلاً بالجميع في تطبيق تواصل برو الذكي! 🚀', time: '10:00 ص', likes: 5 }
    ]);
}

let currentUser = DB.getCurrentUser();
let activePartner = null;

function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}

document.getElementById('signup-btn').addEventListener('click', () => {
    const name = document.getElementById('username-input').value.trim();
    const email = document.getElementById('email-input').value.trim();
    const pass = document.getElementById('password-input').value;
    const errorEl = document.getElementById('auth-error');

    if (!name || !email || !pass) {
        errorEl.textContent = 'يرجى ملء جميع الحقول المطلوبة.';
        return;
    }

    const users = DB.getUsers();
    if (users.find(u => u.email === email)) {
        errorEl.textContent = 'هذا البريد مسجل مسبقاً.';
        return;
    }

    const newUser = { id: 'user_' + Date.now(), name, email, pass };
    users.push(newUser);
    DB.saveUsers(users);
    loginSuccess(newUser);
});

document.getElementById('login-btn').addEventListener('click', () => {
    const email = document.getElementById('email-input').value.trim();
    const pass = document.getElementById('password-input').value;
    const errorEl = document.getElementById('auth-error');

    const users = DB.getUsers();
    const found = users.find(u => u.email === email && u.pass === pass);

    if (!found) {
        errorEl.textContent = 'البريد أو كلمة المرور غير صحيحة.';
        return;
    }

    loginSuccess(found);
});

function loginSuccess(user) {
    currentUser = user;
    DB.setCurrentUser(user);
    document.getElementById('auth-error').textContent = '';
    initMainScreen();
}

document.getElementById('logout-btn').addEventListener('click', () => {
    localStorage.removeItem('app_current_user');
    currentUser = null;
    showScreen('auth-screen');
});

function initMainScreen() {
    document.getElementById('current-user-name').textContent = currentUser.name;
    document.getElementById('edit-name-input').value = currentUser.name;
    renderChatsList();
    renderStatuses();
    showScreen('main-screen');
}

document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.target).classList.add('active');
    });
});

document.getElementById('save-name-btn').addEventListener('click', () => {
    const newName = document.getElementById('edit-name-input').value.trim();
    if (!newName) return alert('يرجى إدخال اسم صحيح');
    
    currentUser.name = newName;
    DB.setCurrentUser(currentUser);
    
    const users = DB.getUsers();
    const index = users.findIndex(u => u.id === currentUser.id);
    if (index !== -1) {
        users[index].name = newName;
        DB.saveUsers(users);
    }

    document.getElementById('current-user-name').textContent = newName;
    alert('تم تحديث الاسم بنجاح!');
});

window.changeTheme = function(primary, dark) {
    document.documentElement.style.setProperty('--primary', primary);
    document.documentElement.style.setProperty('--primary-dark', dark);
    const settings = DB.getSettings();
    settings.primaryColor = primary;
    settings.primaryDark = dark;
    DB.saveSettings(settings);
};

document.getElementById('toggle-dark-mode').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    const settings = DB.getSettings();
    settings.darkMode = isDark;
    DB.saveSettings(settings);
});

document.getElementById('reset-data-btn').addEventListener('click', () => {
    if (confirm('هل أنت متأكد من مسح جميع البيانات؟')) {
        localStorage.clear();
        location.reload();
    }
});

function renderChatsList() {
    const list = document.getElementById('chats-list');
    const allChats = DB.getChats();
    list.innerHTML = '';

    const otherUsers = DB.getUsers().filter(u => u.id !== currentUser.id);
    const contacts = [...botContacts, ...otherUsers];

    contacts.forEach(contact => {
        const chatKey = `${currentUser.id}_${contact.id}`;
        const msgs = allChats[chatKey] || [];
        const lastMsg = msgs.length > 0 ? msgs[msgs.length - 1].text : (contact.bio || 'انقر لبدء المحادثة');

        const card = document.createElement('div');
        card.className = 'user-card';
        card.innerHTML = `
            <div class="avatar">${contact.name.charAt(0)}</div>
            <div class="user-info">
                <h4>${contact.name}</h4>
                <p>${lastMsg}</p>
            </div>
        `;
        card.onclick = () => openChat(contact);
        list.appendChild(card);
    });
}

function openChat(partner) {
    activePartner = partner;
    document.getElementById('chat-partner-name').textContent = partner.name;
    document.getElementById('chat-avatar').textContent = partner.name.charAt(0);
    document.getElementById('chat-partner-status').textContent = 'متصل الآن';
    renderMessages();
    showScreen('chat-room-screen');
}

function renderMessages() {
    const container = document.getElementById('messages-container');
    const allChats = DB.getChats();
    const chatKey = `${currentUser.id}_${activePartner.id}`;
    const msgs = allChats[chatKey] || [];

    container.innerHTML = '';
    msgs.forEach(m => {
        const div = document.createElement('div');
        div.className = `message ${m.sender === currentUser.id ? 'sent' : 'received'}`;
        div.innerHTML = m.text.replace(/\n/g, '<br>') + `<span class="msg-time">${m.time}</span>`;
        container.appendChild(div);
    });
    container.scrollTop = container.scrollHeight;
}

function sendMessage() {
    const input = document.getElementById('message-input');
    const text = input.value.trim();
    if (!text || !activePartner) return;

    input.value = '';
    const now = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    const allChats = DB.getChats();
    const chatKey = `${currentUser.id}_${activePartner.id}`;

    if (!allChats[chatKey]) allChats[chatKey] = [];
    allChats[chatKey].push({ sender: currentUser.id, text, time: now });
    DB.saveChats(allChats);
    renderMessages();

    if (activePartner.generateReply && typeof activePartner.generateReply === 'function') {
        document.getElementById('chat-partner-status').textContent = 'يكتب الآن...';
        setTimeout(() => {
            const smartReply = activePartner.generateReply(text, currentUser);
            const replyTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
            allChats[chatKey].push({ sender: activePartner.id, text: smartReply, time: replyTime });
            DB.saveChats(allChats);
            if (activePartner) {
                document.getElementById('chat-partner-status').textContent = 'متصل الآن';
                renderMessages();
            }
        }, 1200);
    }
}

document.getElementById('send-msg-btn').addEventListener('click', sendMessage);
document.getElementById('message-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

document.getElementById('back-to-main').addEventListener('click', () => {
    activePartner = null;
    renderChatsList();
    showScreen('main-screen');
});

document.getElementById('post-status-btn').addEventListener('click', () => {
    const input = document.getElementById('status-input');
    const text = input.value.trim();
    if (!text) return;

    input.value = '';
    const statuses = DB.getStatuses();
    const now = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    statuses.unshift({ id: Date.now(), author: currentUser.name, text, time: now, likes: 0 });
    DB.saveStatuses(statuses);
    renderStatuses();
});

function renderStatuses() {
    const feed = document.getElementById('status-feed');
    const statuses = DB.getStatuses();
    feed.innerHTML = '';

    statuses.forEach(st => {
        const div = document.createElement('div');
        div.className = 'status-item';
        div.innerHTML = `
            <div class="status-header">
                <span>${st.author}</span>
                <span>${st.time}</span>
            </div>
            <p>${st.text}</p>
            <button class="like-btn" onclick="likeStatus(${st.id})">❤️ إعجاب (${st.likes})</button>
        `;
        feed.appendChild(div);
    });
}

window.likeStatus = function(id) {
    const statuses = DB.getStatuses();
    const target = statuses.find(s => s.id === id);
    if (target) {
        target.likes += 1;
        DB.saveStatuses(statuses);
        renderStatuses();
    }
};

if (currentUser) {
    initMainScreen();
}
